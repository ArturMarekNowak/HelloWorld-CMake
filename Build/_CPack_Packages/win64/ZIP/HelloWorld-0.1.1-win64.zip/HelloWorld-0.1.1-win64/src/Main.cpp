#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
	if (argc > 1)
	{
		return 1;
	}
	cout << "Hello World";
	return 0;
}

